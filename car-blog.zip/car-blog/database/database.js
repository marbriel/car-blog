const { response } = require('express');
const mysql = require('mysql2')

const connection = mysql.createPool({
    host: '127.0.0.1',
    user: 'root',
    password: 'root',
    database: 'car_blog'
}).promise();

async function getUserByEmail(email){
    const user = await connection.query(`SELECT * FROM users WHERE email = ?`, [email]);
    return user[0];
}

async function getUserById(id){
    const user = await connection.query(`SELECT * FROM users WHERE user_id = ?`, [id])
    return user[0];
}

async function registerUser(username, email, password){
    const [result] = await connection.query(`INSERT INTO users (user_name, email, password) VALUES (?, ?, ?)`, [username, email, password]);
    return result.insertId;
}

async function savePost(userId, title, body, image, brand){
    const [result] = await connection.query(`INSERT INTO posts (title, body, date, image, user_id, car_brand) VALUES (?, ?, ?, ?, ?, ?)`, [title, body, new Date().toISOString().slice(0, 10), image, userId, brand]);
    return result.insertId;
}

async function getAllPosts(){
    const[posts] = await connection.query('SELECT * FROM posts INNER JOIN users ON posts.user_id = users.user_id');
    return posts;
}

async function getAllPostsById(id){
    const[posts] = await connection.query('SELECT * FROM posts INNER JOIN users ON posts.user_id = users.user_id WHERE posts.user_id = ?', [id]);
    return posts;
}


async function getPostById(id){
    const [post]  = await connection.query('SELECT * FROM posts INNER JOIN users ON posts.user_id = users.user_id WHERE posts.post_id = ?', [id])
    return post;
}

async function deletePostById(id){
    await connection.query('DELETE FROM posts WHERE post_id = ?', [id]);
}

async function updatePost(id, title, body, image, brand){
    await connection.query(`UPDATE posts SET title = '${title}', body = '${body}', image = '${image}', car_brand = '${brand}' WHERE post_id = ${id}`)
}

async function updateInformation(id, fName, lName, email, profilePic){
    await connection.query('UPDATE users SET firstname = ?, lastname = ?, email = ?, profile_pic = ? WHERE user_id = ?', [fName, lName, email, profilePic, id])
}

async function getPostByCarBrand(brand){
    const [posts] = await connection.query('SELECT * FROM posts INNER JOIN users ON posts.user_id = users.user_id WHERE car_brand = ?' , [brand]);
    return posts;
}

async function deleteUser(id){
    await connection.query('DELETE FROM posts WHERE user_id = ?',[id])
    await connection.query('DELETE FROM users WHERE user_id = ?', [id])
}


module.exports = {getUserByEmail, registerUser, getUserById, savePost, getAllPosts, getAllPostsById, getPostById, deletePostById, updatePost, updateInformation, getPostByCarBrand, deleteUser}