const { request, response } = require('express');
const express = require('express')
const router = express.Router();

router.get('/', (request, response)=>{
    response.send("User")
})


router.get('/register', (request, response)=>{
    response.send('Register New User');
})

module.exports = router