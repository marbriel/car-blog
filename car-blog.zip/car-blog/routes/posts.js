const { response, request } = require('express');
const express = require('express');
const passport = require('passport');
const router = express.Router();














// router.get('/:id', (request, response)=>{
//     console.log(request.params.id)
//     response.send(request.params.id)
// })


router.route('/:id').get((request, response) => {
    response.render('article', { title: 'Car' })
}).put((request, response) => {
    response.send("Updating")
}).delete((request, response) => {
    response.send("DELETE")
})



module.exports = router;