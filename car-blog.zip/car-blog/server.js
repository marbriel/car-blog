const { response, request } = require('express');
const express = require('express');
const app = express();
const path = require('path')
const bcrypt = require('bcrypt')
const passport = require('passport')
const flash = require('express-flash')
const session = require('express-session')
const methodOverride = require('method-override')
const lib = require('./database/database')
const multer = require('multer');

const storage = multer.diskStorage({
    destination: (request, file, callback) =>{
        callback(null, "uploads/")
    },
    filename: (request, file, callback)=>{
        callback(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({storage: storage});

app.set('view engine', 'ejs')
app.use(methodOverride('_method'))
app.use(express.static('public'))
app.use('/uploads', express.static(path.join('uploads')))
app.use('/css', express.static(path.join('node_modules', 'bootstrap', 'dist', 'css')));
app.use('/js', express.static(path.join('node_modules', 'bootstrap', 'dist', 'js')));
app.use('/icons', express.static(path.join('node_modules', 'bootstrap-icons', 'icons')));
app.use('/quill', express.static(path.join('node_modules', 'quill', 'dist')))
app.use('/jquery', express.static(path.join('node_modules', 'jquery', 'dist')))
app.use(express.urlencoded({ extended: false }))
app.use(flash())
app.use(session({
    secret: 'penos',
    resave: false,
    saveUninitialized: false
}))

app.use(passport.initialize())
app.use(passport.session())



const initializePassport = require('./authentication-config');
initializePassport(passport, 
    email => {return lib.getUserByEmail(email)},
    id => {return lib.getUserById(id); }
);



app.post('/login', passport.authenticate('local', {
    successRedirect: '/posts',
    failureRedirect: '/',
    failureFlash: true
}))



app.post('/register', async (request, response) => {
    try {
        const hashed = await bcrypt.hash(request.body.password_register, 10);
        const id = await lib.registerUser(request.body.username_register, request.body.email_register, hashed)
        if(id > 0){
            response.redirect('/'); 
        }

    } catch (err) {
        if (err == 1062) {
            response.redirect('/');
        }
        response.redirect('/')
    }

})


app.get('/posts', checkIfAuthenticated, async (request, response)=>{
    const [user] = await request.user;
    const posts = await lib.getAllPosts()
    const formattedDate = (date) =>{
        let dateUpdate = new Date(date);
        let options = {year: "numeric", month: "long", day: "numeric"}
        let formatted = dateUpdate.toLocaleDateString('en-us', options);
        return formatted
    }
    const formattedPosts = posts.map(post =>{
        return{
            ...post,
            date:  formattedDate(post.date)
        }
    })
    console.log(formattedPosts);
    response.render('other-posts',  { name: user, posts: formattedPosts})
})

app.get('/', checkIfAlreadyInside, async (request, response) => {
    let context = {save: ""};
    let sorted = await getRecommendedArticles(4);
    if(request.query.successful != undefined){
        response.render('login', {save: "Save successfully", recommendations: sorted})
    }

    response.render('login', {save: "", recommendations: sorted})
})

app.get('/create',checkIfAuthenticated, async (request, response) => {
    const [user] = await request.user;
    response.render('create-articles', { title: 'Publish', name: user });
})

app.post('/create', checkIfAuthenticated, upload.single('image_upload'), async (request, response)=>{
    const [user] = await request.user;
    const id = user.user_id;
    const title = request.body.title;
    const body = request.body.body;
    const image = request.file.filename;
    const brand = request.body.brand;
    const isSave = await lib.savePost(id, title, body, image, brand);
    if(isSave > 0){
        response.status(200).redirect('/my-posts')
    }else{
        response.status(500).send("Error saving the data")
    }
    
})

app.get('/my-posts', checkIfAuthenticated, async (request, response) => {
    const [user] = await request.user;
    const posts = await lib.getAllPostsById(user.user_id);
    const formattedDate = (date) =>{
        let dateUpdate = new Date(date);
        let options = {year: "numeric", month: "long", day: "numeric"}
        let formatted = dateUpdate.toLocaleDateString('en-us', options);
        return formatted
    }
    const updatedPosts = posts.map(post =>{
        return{
            ...post,
            date:  formattedDate(post.date)
        }
    })

    
    console.table(user);
    console.log(updatedPosts);
    response.render('my-posts',  { name: user, myposts: updatedPosts })
})

app.get('/article', checkIfAuthenticated, async(request, response)=>{
    let post = {};
    const [user] = await request.user;
    console.log(request.query.id)
    if(request.query.id != undefined){
        const id = request.query.id;
        const formattedDate = (date) =>{
        let dateUpdate = new Date(date);
        let options = {year: "numeric", month: "long", day: "numeric"}
        let formatted = dateUpdate.toLocaleDateString('en-us', options);
        return formatted
    }
        [queryPost] = await lib.getPostById(id);
        post = {...queryPost, date: formattedDate(queryPost.date)}
    }else{
        response.redirect('/posts')
    }

    let sorted = await getRecommendedArticles(6);
    
    
    response.render('article',  {title: post.title , name: user, post: post, recommendeds: sorted})
})

app.get('/user-info', checkIfAuthenticated, async (request, response)=>{
    const [user] = await request.user;
    response.render('user-info', {name: user})
})


app.put('/update-user-info', checkIfAuthenticated, upload.single('image_upload'), async (request, response)=>{
    const [user] = await request.user;
    let id = user.user_id;
    const firstName = request.body.fname;
    const lastName = request.body.lname;
    const email = request.body.email;
    const file = request.file.filename;
    await lib.updateInformation(id, firstName, lastName, email, file);
    console.log({id ,firstName, lastName, email, file})
    response.redirect('/user-info')
})

app.delete('/update-user-info', checkIfAuthenticated, async(request, response)=>{
    const [user] = await request.user;
    await lib.deleteUser(user.user_id);
    request.logout(function(err) {
        if (err) { return next(err); }
        response.redirect('/');
      });

})

app.get('/users-posts', checkIfAuthenticated, async (request, response) =>{
    const [user] = await request.user;
    let id = request.query.id;
    if(user.user_id == id) response.redirect('/my-posts')
    const [whoPost] = await lib.getUserById(id);
    const posts = await lib.getAllPostsById(id);
    const formattedDate = (date) =>{
        let dateUpdate = new Date(date);
        let options = {year: "numeric", month: "long", day: "numeric"}
        let formatted = dateUpdate.toLocaleDateString('en-us', options);
        return formatted
    }
    const updatedPosts = posts.map(post =>{
        return{
            ...post,
            date:  formattedDate(post.date)
        }
    })

    console.log(whoPost)
    response.render('users-posts', {name : user, posts: updatedPosts, whoPost: whoPost})
})


app.get('/car-brand', checkIfAuthenticated, async (request, response)=>{
    const [user] = await request.user;
    let brand = request.query.brand;
    const posts = await lib.getPostByCarBrand(brand)
    const formattedDate = (date) =>{
        let dateUpdate = new Date(date);
        let options = {year: "numeric", month: "long", day: "numeric"}
        let formatted = dateUpdate.toLocaleDateString('en-us', options);
        return formatted
    }
    const updatedPosts = posts.map(post =>{
        return{
            ...post,
            date:  formattedDate(post.date)
        }
    })

    console.log(updatedPosts)
    response.render('car-brands', {name : user, posts: updatedPosts, brand: brand})
})




app.delete('/logout', (request, response)=>{
    request.logout(function(err) {
        if (err) { return next(err); }
        response.redirect('/');
      });
})

app.get('/delete', checkIfAuthenticated, (request, response)=>{
    lib.deletePostById(request.query.id);
    response.redirect('/posts')
})


app.get('/edit', checkIfAuthenticated, async (request, response)=>{
    const [user] = await request.user;
    const [post] = await lib.getPostById(request.query.id)
    response.render('edit-article', {title: "Update Item", post: post, name: user });
})

app.put('/edit', checkIfAuthenticated, upload.single('image_upload'), async(request, response)=>{
    const id = request.body.post_id;
    const title = request.body.title;
    const body = request.body.body;
    const brand = request.body.brand;
    const fileName = request.file.filename;

    console.log(id + " "+ title+ " " + body )
    await lib.updatePost(id, title, body, fileName, brand);
    response.redirect('/my-posts')
})

app.get('/sample', async(request, response) =>{
    if(request.isAuthenticated()){
        response.redirect(`article?id=${request.query.id}`)
    }else{
        response.redirect('/?article=0')
    }

    console.log("Hellow")
})





function checkIfAuthenticated(request, response, next){
    if(request.isAuthenticated()){
        return next()
    }

    response.redirect('/')
}



function checkIfAlreadyInside(request, response, next){
    if(request.isAuthenticated()){
        return response.redirect('/posts')
    }
    next();
}

async function getRecommendedArticles(number){
    let recommended = await lib.getAllPosts();
    let [sorted] = [recommended].sort(()=> Math.random - 0.5)
    for (var a = 0; a < sorted.length; a++) {
        var x = sorted[a];
        var y = Math.floor(Math.random() * (a + 1));
        sorted[a] = sorted[y];
        sorted[y] = x;
    }
    console.log('LENGTH ' +sorted.length)
    if(recommended.length > number){
        sorted = sorted.slice(0, number);
    }

    return sorted;
}


const userRouter = require('./routes/users')
const postsRouter = require('./routes/posts');
const { getMaxListeners } = require('process');
const { render } = require('ejs');
const { post, isNumeric } = require('jquery');
app.use('/user', userRouter);
app.use('/posts', postsRouter)
app.listen(8080)
